<div class="footer">
    <div class="container">
        <b class="copyright">&copy; 2020 Mastared Montessorri </b>All rights reserved.
    </div>
</div>
<script src="{{ asset('scripts/jquery-1.9.1.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('scripts/jquery-ui-1.10.1.custom.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('scripts/flot/jquery.flot.js') }}" type="text/javascript"></script>
<script src="{{ asset('scripts/flot/jquery.flot.resize.js') }}" type="text/javascript"></script>
<script src="{{ asset('scripts/datatables/jquery.dataTables.js') }}" type="text/javascript"></script>
<script src="{{ asset('scripts/common.js') }}" type="text/javascript"></script>