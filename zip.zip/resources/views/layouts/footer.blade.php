<!--Footer-->
<footer id="footer" class="navbar navbar-expand-lg navbar-dark bg-dark">

        <!--Copyright-->
        <div class="footer-text">
            © 2020 Copyright. Developed By Damola Toba 
        </div>
        <!--/.Copyright-->
</footer>
<!--/.Footer-->